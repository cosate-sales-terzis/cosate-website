import { loadPartials } from './modules/partials.js';
import { initLanguageSwitcher, getCurrentTranslations } from './modules/i18n.js';
import { displayProperties } from './modules/properties.js';

// Λειτουργία για τα animations
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
            }
        });
    }, { threshold: 0.1 });

    // Παρακολούθησε τα στοιχεία μετά τη δυναμική φόρτωση
    setTimeout(() => {
        document.querySelectorAll('.animate-on-scroll').forEach(element => {
            observer.observe(element);
        });
    }, 500); // Μικρή καθυστέρηση για να προλάβουν να φορτώσουν τα πάντα
}

// Αρχικοποίηση όλων
document.addEventListener('DOMContentLoaded', async () => {
    await loadPartials();
    await initLanguageSwitcher();
    
    // Πάρε τις τρέχουσες μεταφράσεις και πέρασε τις στη λειτουργία εμφάνισης
    const currentTranslations = getCurrentTranslations();
    await displayProperties(currentTranslations);
    
    initScrollAnimations();

    // Εδώ θα προστεθεί το mobile menu
});